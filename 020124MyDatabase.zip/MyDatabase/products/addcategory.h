#ifndef ADDCATEGORY_H
#define ADDCATEGORY_H

#include <QDialog>

QT_BEGIN_NAMESPACE
class QLabel;
class QPushButton;
class QLineEdit;
QT_END_NAMESPACE

class AddCategory : public QDialog
{
    Q_OBJECT

    private:

        QLineEdit *ctgrIdText;
        QLineEdit *ctgrNameText;

    public:

        AddCategory(QWidget *parent = nullptr);
        QString ctgrId() const;
        QString ctgrName() const;
};

#endif // ADDCATEGORY_H
