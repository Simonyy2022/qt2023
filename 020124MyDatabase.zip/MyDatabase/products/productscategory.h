// Copyright (C) 2016 The Qt Company Ltd.
// SPDX-License-Identifier: LicenseRef-Qt-Commercial OR BSD-3-Clause

#ifndef PRODUCTSCATEGORY_H
#define PRODUCTSCATEGORY_H

#include <QDialog>

QT_BEGIN_NAMESPACE
class QDialogButtonBox;
class QPushButton;
class QCheckBox;
class QSqlTableModel;
class QTableView;
class QLabel;
class QLineEdit;
QT_END_NAMESPACE

class ProductsCategory : public QDialog
{
    Q_OBJECT

    public:

        explicit ProductsCategory(const QString &tableName, QWidget *parent = nullptr);

    private slots:

        void clearFilter();
        void filterRegularExpressionChanged();
        void sortZeroView();
        void sortOneView();
        void showAddEntryDialog();
        void addEntry(const QString &ctgrId, const QString &ctryName);
        void deleteDialog(const QModelIndex& mdlIndex);
        void checkboxStatus();

    private:

        QString tableTempName;

        QLabel *searchLabel;
        QLineEdit *searchText;
        QPushButton *clearButton;

        QPushButton *sortZeroButton;
        QPushButton *sortOneButton;
        QPushButton *addDataButton;
        QCheckBox *deleteCheckbox;
        QPushButton *quitButton;

        QDialogButtonBox *buttonBox;
        QSqlTableModel *tblModel;
        QTableView *tblView;
};

#endif
