// Copyright (C) 2016 The Qt Company Ltd.
// SPDX-License-Identifier: LicenseRef-Qt-Commercial OR BSD-3-Clause

#ifndef REPORTLEDGER_H
#define REPORTLEDGER_H

#include <QDialog>

QT_BEGIN_NAMESPACE
class QDialogButtonBox;
class QPushButton;
class QCheckBox;
class QSqlTableModel;
class QTableView;
class QLabel;
class QLineEdit;
QT_END_NAMESPACE

class ReportLedger : public QDialog
{
    Q_OBJECT

    public:

        explicit ReportLedger(const QString &tableName, QWidget *parent = nullptr);

    private slots:

        void clearFilterItem();
        void clearFilter();
        void filterRegularExpressionChangedItem();
        void filterRegularExpressionChanged();
        // void sortZeroView();
        // void sortOneView();
        void showAddEntryDialog();
        // void addEntry(const QString &ctgrId, const QString &ctryName);
        // void deleteDialog(const QModelIndex& mdlIndex);
        void itemToLedger(const QModelIndex& mdlIndex);
        void itemDouble(const QModelIndex& mdlIndex);
        // void checkboxStatus();

    private:

        QString tableTempName;

        QLabel *searchLabel;
        QLineEdit *searchText;
        QPushButton *clearButton;

        QLabel *searchLabelItem;
        QLineEdit *searchTextItem;
        QPushButton *clearButtonItem;

        // QPushButton *sortZeroButton;
        // QPushButton *sortOneButton;
        // QPushButton *addDataButton;
        // QCheckBox *deleteCheckbox;
        QPushButton *quitButton;

        QDialogButtonBox *buttonBox;

        QSqlTableModel *tblModelItem;
        QSqlTableModel *tblModel;

        QTableView *tblView;
        QTableView *tblViewItem;
};

#endif
