#ifndef EDITQTY_H
#define EDITQTY_H

#include <QDialog>

QT_BEGIN_NAMESPACE
class QLabel;
class QPushButton;
class QLineEdit;
QT_END_NAMESPACE

class EditQty : public QDialog
{
    Q_OBJECT

    private:

        QLabel *rowLabel;
        QLabel *skuLabel;
        QLineEdit *qtyLineEdit;

    public:

        EditQty(const QString &argRow, const QString &argSKU, const QString &argQty,
                QWidget *parent = nullptr);

        QString edRow() const;
        QString edSKU() const;
        QString edQty() const;
};

#endif // EDITQTY_H
