#ifndef TODAYSALES_H
#define TODAYSALES_H

#include <QDialog>
#include <QObject>

QT_BEGIN_NAMESPACE
class QLabel;
class QTextEdit;
class QSqlTableModel;
QT_END_NAMESPACE

class TodaySales : public QDialog
{
    Q_OBJECT

    public:

        explicit TodaySales(QWidget *parent = nullptr);

    private:

        QSqlTableModel *tblModel;

        QLabel *todaySalesLabel;
        QTextEdit *todaySalesTextEdit;


};

#endif // TODAYSALES_H
