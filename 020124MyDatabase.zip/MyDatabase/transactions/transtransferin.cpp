#include "transtransferin.h"

#include <QtWidgets>

TransTransferIn::TransTransferIn(QWidget *parent) : QDialog(parent)
{

}
