// Copyright (C) 2023 The Qt Company Ltd.
// SPDX-License-Identifier: LicenseRef-Qt-Commercial OR GPL-3.0-only

#include "barwidget.h"

#include <QBarCategoryAxis>
#include <QBarSeries>
#include <QBarSet>
#include <QChart>
#include <QLegend>
#include <QValueAxis>

#include <QtSql>

BarWidget::BarWidget(QWidget *parent)
    : ContentWidget(parent)
{
    // -- copy to tblTemporary

    QSqlQuery query;
    QSqlQuery query2; // not mess up with tblsales and tbltemporary

    query2.exec("DELETE FROM tblTemporary");

    tblModel = new QSqlTableModel(this);
    tblModel->setTable("tblSalesMain");

    QVariant value = "" + QDate::currentDate().toString("yyyy-MM-dd") + "";
    tblModel->setFilter(QString("slmDate = '" + value.toString() +"'"));

    tblModel->setSort(0, Qt::AscendingOrder);
    tblModel->select();

    QVariant data[5];

    for(int row=0; row < tblModel->rowCount(); ++row)
    {
        for(int i = 0; i < 5; i++)
        {
            data[i] = tblModel->data(tblModel->index(row,i));
        }

        query.exec("SELECT * FROM tblSales WHERE slsNo == '" + data[0].toString() +"'");
        while (query.next())
        {
            query2.exec("insert into tblTemporary values("
                "'" + query.value(0).toString() + "', "
                "'" + query.value(1).toString() + "', "
                "'" + query.value(2).toString() + "', "
                "'" + query.value(3).toString() + "', "
                "'" + query.value(4).toString() + "', "
                "'" + query.value(5).toString() + "', "
                "'" + query.value(6).toString() + "')");
        }
    }

    query.exec("SELECT column02, SUM(column05), SUM(column06) FROM tblTemporary GROUP BY column02 ORDER BY SUM(column06) DESC");
    QBarSeries *series = new QBarSeries;
    int count=0;
    double amount=0.00;
    QString res = "set";

    while (query.next()) {

        res = "set" + QString::number(count, 'f', 0);

        auto res = new QBarSet("" + query.value(0).toString() +"");
        *res << query.value(2).toInt();
        series->append(res);

        if(query.value(2).toInt() > amount){
            amount = query.value(2).toInt();
        }
        count++;
    }

    // -- set data

    auto chart = new QChart;
    chart->addSeries(series);
    chart->setTitle("Today's Sales by Category (Amount)");
    chart->setAnimationOptions(QChart::SeriesAnimations);

    QStringList categories {"Category"};

    auto axisX = new QBarCategoryAxis;
    axisX->append(categories);
    chart->addAxis(axisX, Qt::AlignBottom);
    series->attachAxis(axisX);

    auto axisY = new QValueAxis;

    axisY->setRange(0,amount+5);

    chart->addAxis(axisY, Qt::AlignLeft);
    series->attachAxis(axisY);

    chart->legend()->setVisible(true);
    chart->legend()->setAlignment(Qt::AlignBottom);

    createDefaultChartView(chart);
}
