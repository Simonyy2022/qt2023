#include "edititeminfo.h"

#include <QtSql>

#include <QtWidgets>

EditItemInfo::EditItemInfo(const QString &argRow, const QString &argSKU,
                const QString &argCategory,
                const QString &argName,
                const QString &argPrice,
                const QString &argQty, QWidget *parent)
                : QDialog(parent),
                itCategoryText(new QComboBox),
                rowLabel(new QLabel),
                skuLabel(new QLabel),
                categoryLineEdit(new QLineEdit),
                nameLineEdit(new QLineEdit),
                priceLineEdit(new QLineEdit),
                qtyLineEdit(new QLineEdit)
{

    originalQty = argQty.toInt();

    // -- set category

    tblModel = new QSqlTableModel(this);
    tblModel->setTable("tblCategory");
    tblModel->setSort(1, Qt::AscendingOrder);
    tblModel->select();

    int indexCategory=0;
    for(int row=0; row < tblModel->rowCount(); ++row)
    {
        QVariant data = tblModel->data(tblModel->index(row,1));
        itCategoryText->addItem("" + data.toString() + "");
        if(data == argCategory) indexCategory = row;
    }

    // -- add widgets

    auto rowLabel0 = new QLabel(tr("Row"));
    rowLabel->setText("" + argRow + "");

    QLabel* rowLabel2 = new QLabel;
    int n = argRow.toInt() + 1; // add 1 to match tblwidget
    rowLabel2->setText("" + QString::number(n) + "");

    auto idLabel = new QLabel(tr("SKU"));
    skuLabel->setText("" + argSKU + "");

    auto categoryLabel = new QLabel(tr("Category"));
    itCategoryText->setCurrentIndex(indexCategory);

    auto nameLabel = new QLabel(tr("Name"));
    nameLineEdit->setText("" + argName + "");

    auto priceLabel = new QLabel(tr("Price"));
    priceLineEdit->setText("" + argPrice + "");
    priceLineEdit->setInputMask("999.99"); // 111223

    auto qtyLabel = new QLabel(tr("Qty"));
    qtyLineEdit->setText("" + argQty + "");
    qtyLineEdit->setValidator( new QIntValidator(0, 100, this) ); // validate number 061223

    auto okButton = new QPushButton(tr("OK"));
    auto cancelButton = new QPushButton(tr("Cancel"));

    // -- gLayout

    auto gLayout = new QGridLayout;

    gLayout->setColumnStretch(1, 2);

    gLayout->addWidget(rowLabel0, 0, 0);
    gLayout->addWidget(rowLabel2, 0, 1); // match with row tblwidget 051223

    gLayout->addWidget(idLabel, 1, 0);
    gLayout->addWidget(skuLabel, 1, 1);

    gLayout->addWidget(categoryLabel, 2, 0);
    gLayout->addWidget(itCategoryText, 2, 1);

    gLayout->addWidget(nameLabel, 3, 0);
    gLayout->addWidget(nameLineEdit, 3, 1);

    gLayout->addWidget(priceLabel, 4, 0);
    gLayout->addWidget(priceLineEdit, 4, 1);

    gLayout->addWidget(qtyLabel, 5, 0);
    gLayout->addWidget(qtyLineEdit, 5, 1);

    // -- buttonLayout

    auto buttonLayout = new QHBoxLayout;

    buttonLayout->addWidget(okButton);
    buttonLayout->addWidget(cancelButton);

    gLayout->addLayout(buttonLayout, 6, 1, Qt::AlignRight);

    // -- mainLayout

    auto mainLayout = new QVBoxLayout;

    mainLayout->addLayout(gLayout);
    setLayout(mainLayout);

    // -- connect singnal and slot

    connect(okButton, &QAbstractButton::clicked, this, &QDialog::accept);
    connect(cancelButton, &QAbstractButton::clicked, this, &QDialog::reject);

    // -- setWindowTitle

    setWindowTitle(tr("Edit Item Info"));

}

QString EditItemInfo::edRow() const
{
    return rowLabel->text();
}

QString EditItemInfo::edSKU() const
{
    return skuLabel->text();
}

QString EditItemInfo::edCategory() const
{
    return itCategoryText->currentText();
}

QString EditItemInfo::edName() const
{
    return nameLineEdit->text();
}

QString EditItemInfo::edPrice() const
{
    return priceLineEdit->text();
}

QString EditItemInfo::edQty() const
{
    return qtyLineEdit->text();
}

QString EditItemInfo::edOriQty() const
{
    return QString::number(originalQty);
}
