#include "todaysales.h"

#include <QtWidgets>
#include <QtSql>

TodaySales::TodaySales(QWidget *parent) : QDialog(parent)
{

    // -- initialize

    QSqlQuery query;
    QSqlQuery query2; // not mess up with tblsales and tbltemporary

    query2.exec("DELETE FROM tblTemporary");

    // -- widgets

    todaySalesLabel = new QLabel(tr("Today's Sales :"));
    todaySalesTextEdit = new QTextEdit;

    // -- set sales main

    tblModel = new QSqlTableModel(this);
    tblModel->setTable("tblSalesMain");

    QVariant value = "" + QDate::currentDate().toString("yyyy-MM-dd") + "";
    tblModel->setFilter(QString("slmDate = '" + value.toString() +"'"));

    tblModel->setSort(0, Qt::AscendingOrder);
    tblModel->select();

    // -- show qty and amount and update tbltemporary

    todaySalesTextEdit->append("Receipt   Date   Time   Qty   Amount");
    todaySalesTextEdit->append("========================");
    todaySalesTextEdit->append("");

    QVariant text = "";
    QVariant data[5];

    int qtyCalculate;
    double amountCalculate;

    for(int row=0; row < tblModel->rowCount(); ++row)
    {
        text = "";
        for(int i = 0; i < 5; i++)
        {
            data[i] = tblModel->data(tblModel->index(row,i));
            if(i == 4){
                amountCalculate = data[i].toDouble();
                text = text.toString() + "" + QString::number(amountCalculate, 'f', 2) + "   ";
            }else{
                text = text.toString() + "" + data[i].toString() + "   ";
            }
        }
        todaySalesTextEdit->append("" + text.toString() + "");

        query.exec("SELECT * FROM tblSales WHERE slsNo == '" + data[0].toString() +"'");
        while (query.next())
        {
            query2.exec("insert into tblTemporary values("
            "'" + query.value(0).toString() + "', "
            "'" + query.value(1).toString() + "', "
            "'" + query.value(2).toString() + "', "
            "'" + query.value(3).toString() + "', "
            "'" + query.value(4).toString() + "', "
            "'" + query.value(5).toString() + "', "
            "'" + query.value(6).toString() + "')");
        }
    }

    // -- sum sales main amount

    todaySalesTextEdit->append("");

    query.exec("SELECT SUM(slmQty), SUM(slmAmount) FROM tblSalesMain WHERE slmDate = '" + value.toString() +"'");

    text = "";
    while (query.next()) {
        qtyCalculate = query.value(0).toInt();
        amountCalculate = query.value(1).toDouble();
        text = text.toString() + "" + QString::number(qtyCalculate, 'f', 0) + "   " + QString::number(amountCalculate, 'f', 2);
    }
    todaySalesTextEdit->append("" + text.toString() + "");

    // -- group by category

    todaySalesTextEdit->append("");
    todaySalesTextEdit->append("By Category");
    todaySalesTextEdit->append("========");
    todaySalesTextEdit->append("");

    query.exec("SELECT column02, SUM(column05), SUM(column06) FROM tblTemporary GROUP BY column02 ORDER BY SUM(column06) DESC");
    text = "";
    int qty = 0;
    double amount = 0.00;
    while (query.next()) {
        qty = qty + query.value(1).toInt();
        amount = amount + query.value(2).toDouble();
        amountCalculate = query.value(2).toDouble();
        text = text.toString() + "" + query.value(0).toString() + "     " + query.value(1).toString()+ "     " + QString::number(amountCalculate, 'f', 2);
        todaySalesTextEdit->append("" + text.toString() + "");
        text = "";
    }
    todaySalesTextEdit->append("");
    todaySalesTextEdit->append("" + QString::number(qty) + "    " + QString::number(amount, 'f', 2) + "");

    // -- group by name

    todaySalesTextEdit->append("");
    todaySalesTextEdit->append("By Name");
    todaySalesTextEdit->append("======");
    todaySalesTextEdit->append("");

    query.exec("SELECT column03, SUM(column05), SUM(column06) FROM tblTemporary GROUP BY column03 ORDER BY SUM(column06) DESC");
    text = "";
    qty = 0;
    amount = 0.00;
    while (query.next()) {
        qty = qty + query.value(1).toInt();
        amount = amount + query.value(2).toDouble();
        amountCalculate = query.value(2).toDouble();
        text = text.toString() + "" + query.value(0).toString() + "     " + query.value(1).toString()+ "     " + QString::number(amountCalculate, 'f', 2);
        todaySalesTextEdit->append("" + text.toString() + "");
        text = "";
    }
    todaySalesTextEdit->append("");
    todaySalesTextEdit->append("" + QString::number(qty) + "    " + QString::number(amount, 'f', 2) + "");

    // -- layout

    QVBoxLayout *mainLayout = new QVBoxLayout;
    mainLayout->addWidget(todaySalesLabel);
    mainLayout->addWidget(todaySalesTextEdit);
    setLayout(mainLayout);

    // -- set window title

    setWindowTitle(tr("Today's Sales"));

}
