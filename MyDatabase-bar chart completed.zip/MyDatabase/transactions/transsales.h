#ifndef TRANSSALES_H
#define TRANSSALES_H

#include <QDialog>
#include <QObject>

#include <QTableWidget>

QT_BEGIN_NAMESPACE
class QTableView;
class QLabel;
class QLineEdit;
class QDialogButtonBox;
class QPushButton;
class QSqlTableModel;
class QSpacerItem;
QT_END_NAMESPACE

class TransSales : public QDialog
{

    Q_OBJECT

    public:

        explicit TransSales(QWidget *parent = nullptr);

    private:

        QLabel *skuLabel;
        QLineEdit *searchText;
        QPushButton *enterButton;
        QPushButton *completedButton;

        QTableWidget *twSales;

        QLabel *qtyLabel;
        QLabel *amountLabel;
        QSpacerItem *space1;

        QSqlTableModel *tblModel;

    private slots:

        void skuEnter();
        void completedEnter();
        void deleteEdit(const QModelIndex& mdlIndex);
        void updateTblWidgwt(const QString &edRow, const QString &edSKU,
                             const QString &edQty);
        void calculateSales();

};

#endif // TRANSSALES_H
