#ifndef PRODUCTSITEM_H
#define PRODUCTSITEM_H

#include <QDialog>
#include <QObject>

QT_BEGIN_NAMESPACE
class QSqlTableModel;
class QSqlRelationalTableModel;
class QTableView;
class QLabel;
class QLineEdit;
class QCheckBox;
class QDialogButtonBox;
class QPushButton;
QT_END_NAMESPACE

class ProductsItem : public QDialog
{
    Q_OBJECT

    public:

        explicit ProductsItem(QWidget *parent = nullptr);

    private:

        QSqlTableModel *tblModel;
        QTableView *tblView;

        QLabel *searchLabel;
        QLineEdit *searchText;
        QPushButton *clearButton;

        QPushButton *sortZeroButton;
        QPushButton *sortOneButton;
        QPushButton *addDataButton;
        QCheckBox *deleteCheckbox;
        QPushButton *quitButton;

        QDialogButtonBox *buttonBox;

    private slots:

        void filterRegularExpressionChanged();
        void clearFilter();
        void sortZeroView();
        void sortOneView();
        void showAddEntryDialog();
        void checkboxStatus();
        void deleteDialog(const QModelIndex& mdlIndex);
        void addEntry(const QString &itemSKU, const QString &itemCategory,
        const QString &itemItem, const QString &itemPrice, const QString &itemQty);

        void updateTblWidgwt(const QString &edSKU,
                             const QString &edCategory, const QString &edName,
                             const QString &edPrice, const QString &edQty,
                             const QString &edOriQty);
};

#endif // PRODUCTSITEM_H
