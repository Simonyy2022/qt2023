#include "editqty.h"

#include <QtWidgets>

EditQty::EditQty(const QString &argRow, const QString &argSKU,
                 const QString &argQty, QWidget *parent)
                : QDialog(parent),
                rowLabel(new QLabel),
                skuLabel(new QLabel),
                qtyLineEdit(new QLineEdit)
{
    // -- add widgets

    auto rowLabel0 = new QLabel(tr("Row"));
    rowLabel->setText("" + argRow + "");

    QLabel* rowLabel2 = new QLabel;
    int n = argRow.toInt() + 1; // add 1 to match tblwidget
    rowLabel2->setText("" + QString::number(n) + "");

    auto idLabel = new QLabel(tr("SKU"));
    skuLabel->setText("" + argSKU + "");

    auto nameLabel = new QLabel(tr("Qty"));
    qtyLineEdit->setText("" + argQty + "");

    qtyLineEdit->setValidator( new QIntValidator(0, 100, this) ); // validate number 061223

    auto okButton = new QPushButton(tr("OK"));
    auto cancelButton = new QPushButton(tr("Cancel"));

    // -- gLayout

    auto gLayout = new QGridLayout;

    gLayout->setColumnStretch(1, 2);

    gLayout->addWidget(rowLabel0, 0, 0);
    gLayout->addWidget(rowLabel2, 0, 1); // match with row tblwidget 051223

    gLayout->addWidget(idLabel, 1, 0);
    gLayout->addWidget(skuLabel, 1, 1);

    gLayout->addWidget(nameLabel, 2, 0);
    gLayout->addWidget(qtyLineEdit, 2, 1);

    // -- buttonLayout

    auto buttonLayout = new QHBoxLayout;

    buttonLayout->addWidget(okButton);
    buttonLayout->addWidget(cancelButton);

    gLayout->addLayout(buttonLayout, 3, 1, Qt::AlignRight);

    // -- mainLayout

    auto mainLayout = new QVBoxLayout;

    mainLayout->addLayout(gLayout);
    setLayout(mainLayout);

    // -- connect singnal and slot

    connect(okButton, &QAbstractButton::clicked, this, &QDialog::accept);
    connect(cancelButton, &QAbstractButton::clicked, this, &QDialog::reject);

    // -- setWindowTitle

    setWindowTitle(tr("Edit Qty"));
}

QString EditQty::edRow() const
{
    return rowLabel->text();
}

QString EditQty::edSKU() const
{
    return skuLabel->text();
}

QString EditQty::edQty() const
{
    return qtyLineEdit->text();
}

