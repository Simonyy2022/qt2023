#include "addcategory.h"

#include <QtWidgets>

AddCategory::AddCategory(QWidget *parent) : QDialog(parent),
    ctgrIdText(new QLineEdit),
    ctgrNameText(new QLineEdit)
{
    // -- add button

    auto idLabel = new QLabel(tr("ID"));
    auto nameLabel = new QLabel(tr("Category"));

    auto okButton = new QPushButton(tr("OK"));
    auto cancelButton = new QPushButton(tr("Cancel"));

    // -- gLayout

    auto gLayout = new QGridLayout;
    gLayout->setColumnStretch(1, 2);

    gLayout->addWidget(idLabel, 0, 0);
    gLayout->addWidget(ctgrIdText, 0, 1);

    gLayout->addWidget(nameLabel, 1, 0);
    gLayout->addWidget(ctgrNameText, 1, 1);

    // -- buttonLayout

    auto buttonLayout = new QHBoxLayout;
    buttonLayout->addWidget(okButton);
    buttonLayout->addWidget(cancelButton);

    gLayout->addLayout(buttonLayout, 3, 1, Qt::AlignRight);

    // -- mainLayout

    auto mainLayout = new QVBoxLayout;
    mainLayout->addLayout(gLayout);
    setLayout(mainLayout);

    connect(okButton, &QAbstractButton::clicked, this, &QDialog::accept);
    connect(cancelButton, &QAbstractButton::clicked, this, &QDialog::reject);

    setWindowTitle(tr("Add Category"));
}

QString AddCategory::ctgrId() const
{
    return ctgrIdText->text();
}

QString AddCategory::ctgrName() const
{
    return ctgrNameText->text();
}

