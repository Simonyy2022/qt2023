#include "additem.h"

#include <QtWidgets>

#include <QSqlTableModel>

AddItem::AddItem(QWidget *parent) : QDialog(parent),
    itSKUText(new QLineEdit),
    itCategoryText(new QComboBox),
    itNameText(new QLineEdit),
    itPriceText(new QLineEdit),
    itQtyText(new QLineEdit)
{

    // -- set category

    tblModel = new QSqlTableModel(this);
    tblModel->setTable("tblCategory");
    tblModel->setSort(1, Qt::AscendingOrder);
    tblModel->select();

    for(int row=0; row < tblModel->rowCount(); ++row)
    {
        QVariant data = tblModel->data(tblModel->index(row,1));
        itCategoryText->addItem("" + data.toString() + "");
    }

    // -- add button

    auto SKULabel = new QLabel(tr("SKU"));
    auto categoryLabel = new QLabel(tr("Category"));
    auto nameLabel = new QLabel(tr("Item"));
    auto priceLabel = new QLabel(tr("Price"));
    auto qtyLabel = new QLabel(tr("Qty"));

    auto okButton = new QPushButton(tr("OK"));
    auto cancelButton = new QPushButton(tr("Cancel"));

    // -- gLayout

    auto gLayout = new QGridLayout;
    gLayout->setColumnStretch(1, 2);

    gLayout->addWidget(SKULabel, 0, 0);
    gLayout->addWidget(itSKUText, 0, 1);

    gLayout->addWidget(categoryLabel, 1, 0);
    gLayout->addWidget(itCategoryText, 1, 1);

    gLayout->addWidget(nameLabel, 2, 0);
    gLayout->addWidget(itNameText, 2, 1);

    gLayout->addWidget(priceLabel, 3, 0);
    gLayout->addWidget(itPriceText, 3, 1);
    itPriceText->setInputMask("999.99"); // 111223

    gLayout->addWidget(qtyLabel, 4, 0);
    gLayout->addWidget(itQtyText, 4, 1);

    itQtyText->setValidator( new QIntValidator(0, 100, this) ); // validate number 061223

    // -- buttonLayout

    auto buttonLayout = new QHBoxLayout;
    buttonLayout->addWidget(okButton);
    buttonLayout->addWidget(cancelButton);

    gLayout->addLayout(buttonLayout, 5, 1, Qt::AlignRight);

    // -- mainLayout

    auto mainLayout = new QVBoxLayout;
    mainLayout->addLayout(gLayout);
    setLayout(mainLayout);

    connect(okButton, &QAbstractButton::clicked, this, &QDialog::accept);
    connect(cancelButton, &QAbstractButton::clicked, this, &QDialog::reject);

    setWindowTitle(tr("Add a Item"));
}

QString AddItem::itemSKU() const
{
    return itSKUText->text();
}

QString AddItem::itemCategory() const
{
    return itCategoryText->currentText();
}

QString AddItem::itemItem() const
{
    return itNameText->text();
}

QString AddItem::itemPrice() const
{
    return itPriceText->text();
}

QString AddItem::itemQty() const
{
    return itQtyText->text();
}

