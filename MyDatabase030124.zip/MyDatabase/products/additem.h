#ifndef AddItem_H
#define AddItem_H

#include <QDialog>
#include <QObject>

QT_BEGIN_NAMESPACE
class QLabel;
class QPushButton;
class QLineEdit;
class QSqlTableModel;
class QComboBox;
QT_END_NAMESPACE

class AddItem : public QDialog
{
    Q_OBJECT

    private:

        QLineEdit *itSKUText;
        QComboBox *itCategoryText;
        QLineEdit *itNameText;
        QLineEdit *itPriceText;
        QLineEdit *itQtyText;
        QSqlTableModel *tblModel;

    public:

        AddItem(QWidget *parent = nullptr);
        QString itemSKU() const;
        QString itemCategory() const;
        QString itemItem() const;
        QString itemPrice() const;
        QString itemQty() const;
};

#endif // AddItem_H
