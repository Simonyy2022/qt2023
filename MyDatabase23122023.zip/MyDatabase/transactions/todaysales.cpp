#include "todaysales.h"

#include <QtWidgets>
#include <QtSql>

TodaySales::TodaySales(QWidget *parent) : QDialog(parent)
{

    // -- widgets

    todaySalesLabel = new QLabel(tr("Today's Sales : "));
    todaySalesTextEdit = new QTextEdit;

    // -- set sales main jj

    tblModel = new QSqlTableModel(this);
    tblModel->setTable("tblSalesMain");
    tblModel->setSort(0, Qt::AscendingOrder);
    tblModel->select();

    // QVariant value = searchText->text();

    // tblModel->setFilter(QString("itemSKU like '%%1%' OR itemCategory like '%%1%' "
    //                             "OR itemName like '%%1%'").arg(value.toString()));

    todaySalesTextEdit->append("Receipt   Date   Time   Qty   Amount");

    for(int row=0; row < tblModel->rowCount(); ++row)
    {
        QVariant text = "";
        QVariant data[5];
        for(int i = 0; i < 5; i++)
        {
            data[i] = tblModel->data(tblModel->index(row,i));
            // qDebug() << "data " << data[i];
            text = text.toString() + "  " + data[i].toString();
        }
        todaySalesTextEdit->append("" + text.toString() + "");
    }

    // -- layout

    QVBoxLayout *mainLayout = new QVBoxLayout;
    mainLayout->addWidget(todaySalesLabel);
    mainLayout->addWidget(todaySalesTextEdit);
    setLayout(mainLayout);

    // -- set window title

    setWindowTitle(tr("Today's Sales"));

}
