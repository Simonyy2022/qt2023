// Copyright (C) 2016 The Qt Company Ltd.
// SPDX-License-Identifier: LicenseRef-Qt-Commercial OR BSD-3-Clause

#include "mainwindow.h"

#include <QApplication>

#include <QSqlDatabase>
#include <QMessageBox>
#include <QSqlQuery>

static bool createConnection()
{

    //-- check QSQLITE

    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");

    //-- use working directory

    QString result;
    result.append(PROJECT_PATH);
    result.append("pos.db");
    db.setDatabaseName("" + result +"");

    //-- check database open

    if (!db.open()) {
        QMessageBox::critical(nullptr, QObject::tr("Cannot open database"),
                              QObject::tr("Unable to establish a database connection.\n"
                                          "This example needs SQLite support. Please read "
                                          "the Qt SQL driver documentation for information how "
                                          "to build it.\n\n"
                                          "Click Cancel to exit."), QMessageBox::Cancel);
        return false;
    }

    QSqlQuery query;

    // -- tblCategory

    query.exec("create table tblCategory (ctgId varchar(20) primary key, "
               "ctgName varchar(20))");

    // demo data category

    query.exec("insert into tblCategory values('101', 'Cake')");
    query.exec("insert into tblCategory values('102', 'Bread')");
    query.exec("insert into tblCategory values('103', 'Coffee')");

    // -- tblItem

    query.exec("create table tblItem (itemSKU varchar(20) primary key, "
               "itemCategory varchar(20), "
               "itemName varchar(20), itemPrice double, itemQty int)");

    // demo data item

    query.exec("insert into tblItem values('201', 'Cake', 'Cheese Cake', 20.75, 100)");
    query.exec("insert into tblItem values('202', 'Bread', 'Banana Bread', 8.00, 100)");
    query.exec("insert into tblItem values('203', 'Coffee', 'Mocha Coffee', 6.50, 100)");

    // -- tblLedger

    query.exec("create table tblLedger (ledDate smalldatetime, "
               "ledTime smalldatetime, "
               "ledDetail varchar(20), "
               "ledNumber varchar(20), "
               "ledSKU varchar(20), "
               "ledCategory varchar(20), "
               "ledName varchar(20), "
               "ledPrice double, ledQty int, ledBalance int)");

    // -- tblSales

    query.exec("create table tblSales (slsNo varchar(20), "
               "slsSKU varchar(20), "
               "slsCategory varchar(20), "
               "slsName varchar(20), "
               "slsPrice double, "
               "slsQty int, slsAmount double)");

    // -- tblSalesMain

    query.exec("create table tblSalesMain (slmNo varchar(20) primary key, "
               "slmDate smalldatetime, "
               "slmTime smalldatetime, "
               "slmQty int, slmAmount double)");

    // -- tblNumbers

    query.exec("create table tblNumbers (numType varchar(20) primary key, "
               "numNumber int)");

    // set tblNumbers initialize data

    query.exec("insert into tblNumbers values('Sales', 0)");
    query.exec("insert into tblNumbers values('Transfer In', 0)");

    return true;
}

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);

    if (!createConnection())
        return 1;

    MainWindow mw;
    mw.resize(800,500);
    mw.show();

    return app.exec();
}


