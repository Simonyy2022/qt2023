#include "productsitem.h"
#include "addItem.h"
#include "edititeminfo.h"

#include <QtWidgets>
#include <QtSql>

ProductsItem::ProductsItem(QWidget *parent) : QDialog(parent)
{
    // qtyCount = 0;

    // -- set table

    tblModel = new QSqlTableModel(this);
    tblModel->setTable("tblItem");
    tblModel->setEditStrategy(QSqlTableModel::OnFieldChange);
    tblModel->setSort(0, Qt::AscendingOrder);        
    tblModel->select();

    // -- set header

    tblModel->setHeaderData(0, Qt::Horizontal, tr("SKU"));
    tblModel->setHeaderData(1, Qt::Horizontal, tr("Category"));
    tblModel->setHeaderData(2, Qt::Horizontal, tr("Item"));
    tblModel->setHeaderData(3, Qt::Horizontal, tr("Price"));
    tblModel->setHeaderData(4, Qt::Horizontal, tr("Qty"));

    // -- put data into QTableView

    tblView = new QTableView(this);
    tblView->setModel(tblModel);
    tblView->horizontalHeader()->setDefaultAlignment(Qt::AlignLeft); // header alignment
    tblView->resizeColumnsToContents();
    tblView->setStyleSheet("QTableView { border: none;"
                        "background-color: white;"
                        "selection-color: black;"
                        "selection-background-color: cyan}");

    // -- set button

    searchLabel = new QLabel(tr("Search Text : "));
    searchText = new QLineEdit();
    clearButton = new QPushButton(tr("Clear"));

    sortZeroButton = new QPushButton(tr("Sort SKU"));
    sortZeroButton->setDefault(true);
    sortOneButton = new QPushButton(tr("Sort Category"));
    addDataButton = new QPushButton(tr("Add"));
    deleteCheckbox = new QCheckBox(tr("Delete"));
    quitButton = new QPushButton(tr("Quit"));

    // -- put button into button box

    buttonBox = new QDialogButtonBox(Qt::Vertical);

    buttonBox->addButton(sortZeroButton, QDialogButtonBox::ActionRole);
    buttonBox->addButton(sortOneButton, QDialogButtonBox::ActionRole);
    buttonBox->addButton(addDataButton, QDialogButtonBox::ActionRole);
    buttonBox->addButton(deleteCheckbox, QDialogButtonBox::ActionRole);
    buttonBox->addButton(quitButton, QDialogButtonBox::RejectRole);

    // -- connect button signal and slot

    connect(searchText, &QLineEdit::textChanged,
            this, &ProductsItem::filterRegularExpressionChanged);

    connect(clearButton, &QPushButton::clicked, this, &ProductsItem::clearFilter);
    connect(sortZeroButton, &QPushButton::clicked, this, &ProductsItem::sortZeroView);
    connect(sortOneButton, &QPushButton::clicked, this, &ProductsItem::sortOneView);
    connect(addDataButton, &QPushButton::clicked, this, &ProductsItem::showAddEntryDialog);
    connect(deleteCheckbox, &QCheckBox::clicked, this, &ProductsItem::checkboxStatus);
    connect(quitButton, &QPushButton::clicked, this, &ProductsItem::close);

    connect(tblView, SIGNAL(clicked(QModelIndex)), this, SLOT(deleteDialog(QModelIndex)));

    // -- add view into QHBoxLayout

    QHBoxLayout *searchLayout = new QHBoxLayout;
    searchLayout->addWidget(searchLabel);
    searchLayout->addWidget(searchText);
    searchLayout->addWidget(clearButton);

    QVBoxLayout *firstLayout = new QVBoxLayout();
    firstLayout->addLayout(searchLayout);
    firstLayout->addWidget(tblView);

    QHBoxLayout *mainLayout = new QHBoxLayout;
    mainLayout->addLayout(firstLayout);
    mainLayout->addWidget(buttonBox);
    setLayout(mainLayout);

    // -- set window title

    setWindowTitle(tr("Item"));
}

void ProductsItem::filterRegularExpressionChanged()
{
    qDebug() << "filterRegularExpressionChanged " << searchText->text();

    QVariant value = searchText->text();

    tblModel->setFilter(QString("itemSKU like '%%1%' OR itemCategory like '%%1%' "
                                "OR itemName like '%%1%'").arg(value.toString()));

    tblModel->setSort(0, Qt::AscendingOrder);
    tblModel->select();
}

void ProductsItem::clearFilter()
{
    searchText->setText("");
    tblModel->setFilter("");
    tblModel->setSort(0, Qt::AscendingOrder);
    tblModel->select();
    tblView->resizeColumnsToContents();
}

void ProductsItem::sortZeroView()
{
    tblModel->setSort(0, Qt::AscendingOrder);
    tblModel->select();
}

void ProductsItem::sortOneView()
{
    tblModel->setSort(1, Qt::AscendingOrder);
    tblModel->select();
}

void ProductsItem::showAddEntryDialog()
{
    AddItem aDialog;

    if (aDialog.exec())
        addEntry(aDialog.itemSKU(), aDialog.itemCategory(), aDialog.itemItem(),
             aDialog.itemPrice(), aDialog.itemQty());

}

void ProductsItem::checkboxStatus()
{
    if (deleteCheckbox->checkState()) {
        tblView->setStyleSheet("QTableView { border: none;"
                               "background-color: pink;"
                               "selection-color: black;"
                               "selection-background-color: yellow}");
    }else{
        tblView->setStyleSheet("QTableView { border: none;"
                               "background-color: white;"
                               "selection-color: black;"
                               "selection-background-color: cyan}");
    }
}

void ProductsItem::addEntry(const QString &itemSKU, const QString &itemCategory,
        const QString &itemItem, const QString &itemPrice, const QString &itemQty)
{
    QSqlQuery query;

    query.exec("insert into tblItem values('"+ itemSKU +"', '"+ itemCategory +"', "
          "'"+ itemItem +"', '"+ itemPrice +"', '"+ itemQty +"')");

    query.exec("insert into tblLedger values("
        "'" + QDate::currentDate().toString("yyyy-MM-dd") + "', "
        "'" + QTime::currentTime().toString("hh:mm:ss") + "', "
        "'Opening', 'Null',"
        "'"+ itemSKU +"', '"+ itemCategory +"', "
        "'"+ itemItem +"', '"+ itemPrice +"', '"+ itemQty +"', '"+ itemQty +"')");

    tblModel->select();
    tblView->resizeColumnsToContents();
}

void ProductsItem::deleteDialog(const QModelIndex& index)
{
    if (deleteCheckbox->checkState())
    {
        QMessageBox msgBox(QMessageBox::Question, tr("Delete?!"),
                           tr("Delete this record?"), { }, this);
        msgBox.addButton(QMessageBox::Yes);
        msgBox.addButton(QMessageBox::No);
        msgBox.setDefaultButton(QMessageBox::No);
        int reply = msgBox.exec();

        if (reply == QMessageBox::Yes){
            QVariant value = index.sibling(index.row(),0).data(); //will return cell
            QSqlQuery query;
            query.exec("DELETE FROM tblItem WHERE itemSKU='" + value.toString() + "'");
            tblModel->setSort(0, Qt::AscendingOrder);
            tblModel->select();
        }
    }else{

        QMessageBox msgBox(QMessageBox::Question, tr("Edit?!"),
                           tr("Edit this record?"), { }, this);
        msgBox.addButton(QMessageBox::Yes);
        msgBox.addButton(QMessageBox::No);
        msgBox.setDefaultButton(QMessageBox::No);
        int reply = msgBox.exec();

        if (reply == QMessageBox::Yes){

            qDebug() << "--------- ProductsItem::deleteDialog";
            qDebug() << "row " << index.row();
            qDebug() << "SKU " << index.sibling(index.row(),0).data();
            qDebug() << "category " << index.sibling(index.row(),1).data();
            qDebug() << "name " << index.sibling(index.row(),2).data();
            qDebug() << "price " << index.sibling(index.row(),3).data();
            qDebug() << "qty " << index.sibling(index.row(),4).data();

            QVariant row = index.row();
            QVariant sku = index.sibling(index.row(),0).data();
            QVariant category = index.sibling(index.row(),1).data();
            QVariant name = index.sibling(index.row(),2).data();
            QVariant price = index.sibling(index.row(),3).data();
            QVariant qty = index.sibling(index.row(),4).data();

            EditItemInfo showDialog(""+ row.toString() + "", ""+ sku.toString() + "",
                        ""+ category.toString() + "", ""+ name.toString() + "",
                        ""+ price.toString() + "", ""+ qty.toString() + "");

            if (showDialog.exec())
                updateTblWidgwt(showDialog.edSKU(),
                                showDialog.edCategory(), showDialog.edName(),
                                showDialog.edPrice(), showDialog.edQty(),
                                showDialog.edOriQty());
        }
    }
} // void ProductsItem::deleteDialog

void ProductsItem::updateTblWidgwt(const QString &sku,
    const QString &category, const QString &name,
    const QString &price, const QString &qty, const QString &oriqty)
{
    QSqlQuery query;

    query.exec("UPDATE tblItem SET itemCategory = '" + category + "'"
                ", itemName = '" + name + "' "
                ", itemPrice = '" + price + "' "
                ", itemQty = '" + qty + "' "
                "WHERE itemSKU = '"+ sku +"'");

    if(oriqty != qty)
    {
        int adjustQty = oriqty.toInt() - qty.toInt();
        QSqlQuery query;
        query.exec("insert into tblLedger values("
            "'" + QDate::currentDate().toString("yyyy-MM-dd") + "', "
            "'" + QTime::currentTime().toString("hh:mm:ss") + "', "
            "'Adjustment', 'Null',"
            "'"+ sku +"', "
            "'"+ category +"', "
            "'"+ name +"', "
            "'"+ price +"', "
            "'"+ QString::number(adjustQty) +"', "
            "'"+ qty +"')");
    }

    tblModel->select();
    tblView->resizeColumnsToContents();

} // end of ProductsItem::updateTblWidgwt
