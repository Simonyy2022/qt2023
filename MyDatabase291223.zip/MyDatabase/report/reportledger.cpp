// Copyright (C) 2016 The Qt Company Ltd.
// SPDX-License-Identifier: LicenseRef-Qt-Commercial OR BSD-3-Clause

#include <QtWidgets>
#include <QtSql>

#include "reportledger.h"

#include <QModelIndex>

ReportLedger::ReportLedger(const QString &tableName, QWidget *parent)
    : QDialog(parent)
{
    // -- set table item

    tblModelItem = new QSqlTableModel(this);
    tblModelItem->setTable("tblItem");
    tblModelItem->setEditStrategy(QSqlTableModel::OnManualSubmit);
    tblModelItem->setSort(0, Qt::AscendingOrder);
    tblModelItem->select();

    // -- set header item

    tblModelItem->setHeaderData(0, Qt::Horizontal, tr("SKU"));
    tblModelItem->setHeaderData(1, Qt::Horizontal, tr("Category"));
    tblModelItem->setHeaderData(2, Qt::Horizontal, tr("Item"));
    tblModelItem->setHeaderData(3, Qt::Horizontal, tr("Price"));
    tblModelItem->setHeaderData(4, Qt::Horizontal, tr("Qty"));

    // -- put data into tableview item

    tblViewItem = new QTableView(this);
    tblViewItem->setModel(tblModelItem);
    tblViewItem->resizeColumnsToContents();
    tblViewItem->setStyleSheet("QTableView { border: none;"
                           "background-color: white;"
                           "selection-color: black;"
                           "selection-background-color: cyan}");

    // -- set button item

    searchLabelItem = new QLabel(tr("Search : "));
    searchTextItem = new QLineEdit();
    clearButtonItem = new QPushButton(tr("Clear"));

    // -- define temp table name
    tableTempName = tableName;

    // -- set table
    tblModel = new QSqlTableModel(this);
    tblModel->setTable(tableName);
    tblModel->setEditStrategy(QSqlTableModel::OnManualSubmit);
    tblModel->setSort(0, Qt::AscendingOrder);
    tblModel->select();

    // -- set header
    tblModel->setHeaderData(0, Qt::Horizontal, tr("Date"));
    tblModel->setHeaderData(1, Qt::Horizontal, tr("Time"));
    tblModel->setHeaderData(2, Qt::Horizontal, tr("Type"));
    tblModel->setHeaderData(3, Qt::Horizontal, tr("Number #"));
    tblModel->setHeaderData(4, Qt::Horizontal, tr("SKU"));
    tblModel->setHeaderData(5, Qt::Horizontal, tr("Category"));
    tblModel->setHeaderData(6, Qt::Horizontal, tr("Name"));
    tblModel->setHeaderData(7, Qt::Horizontal, tr("Price"));
    tblModel->setHeaderData(8, Qt::Horizontal, tr("Qty"));
    tblModel->setHeaderData(9, Qt::Horizontal, tr("Balance"));

    // -- put data into tableview

    tblView = new QTableView(this);
    tblView->setModel(tblModel);
    tblView->resizeColumnsToContents();
    tblView->setStyleSheet("QTableView { border: none;"
                           "background-color: white;"
                           "selection-color: black;"
                           "selection-background-color: cyan}");

    // -- set button

    searchLabel = new QLabel(tr("Search SKU : "));
    searchText = new QLineEdit();
    clearButton = new QPushButton(tr("Clear"));
    quitButton = new QPushButton(tr("Quit"));

    // -- put button into button box

    buttonBox = new QDialogButtonBox(Qt::Vertical);
    buttonBox->addButton(quitButton, QDialogButtonBox::RejectRole);

    // -- connect button signal and slot

    connect(searchTextItem, &QLineEdit::textChanged,
            this, &ReportLedger::filterRegularExpressionChangedItem);

    connect(clearButtonItem, &QPushButton::clicked, this, &ReportLedger::clearFilterItem);

    connect(searchText, &QLineEdit::textChanged,
            this, &ReportLedger::filterRegularExpressionChanged);

    connect(clearButton, &QPushButton::clicked, this, &ReportLedger::clearFilter);

    connect(quitButton, &QPushButton::clicked, this, &ReportLedger::close);

    connect(tblViewItem, SIGNAL(clicked(QModelIndex)), this, SLOT(itemToLedger(QModelIndex)));

    //jj
    connect(tblViewItem, SIGNAL(doubleclicked(QModelIndex)), this, SLOT(itemDouble(QModelIndex)));

    // -- add view into QHBoxLayout

    QHBoxLayout *searchLayoutItem = new QHBoxLayout;
    searchLayoutItem->addWidget(searchLabelItem);
    searchLayoutItem->addWidget(searchTextItem);
    searchLayoutItem->addWidget(clearButtonItem);

    QHBoxLayout *searchLayout = new QHBoxLayout;
    searchLayout->addWidget(searchLabel);
    searchLayout->addWidget(searchText);
    searchLayout->addWidget(clearButton);

    QVBoxLayout *firstLayout = new QVBoxLayout();
    firstLayout->addLayout(searchLayoutItem);
    firstLayout->addWidget(tblViewItem);
    firstLayout->addLayout(searchLayout);
    firstLayout->addWidget(tblView);

    QHBoxLayout *mainLayout = new QHBoxLayout;
    mainLayout->addLayout(firstLayout);
    mainLayout->addWidget(buttonBox);
    setLayout(mainLayout);

    // -- set window title

    setWindowTitle(tr("Ledger"));

    qDebug() << "ReportLedger::ReportLedger --" << tableName;
}

void ReportLedger::showAddEntryDialog()
{
}

// void ReportLedger::addEntry(const QString &id, const QString &name)
// {
//     QSqlQuery query;

//     qDebug() << "tempname 2" << tableTempName;

//     query.exec("insert into " + tableTempName + " values('"+id+"', '"+name+"')");
//     tblModel->select();
//     tblView->resizeColumnsToContents();
// }

// void ReportLedger::sortZeroView()
// {
//     tblModel->setSort(0, Qt::AscendingOrder);
//     tblModel->select();
// }

// void ReportLedger::sortOneView()
// {
//     tblModel->setSort(1, Qt::AscendingOrder);
//     tblModel->select();
// }

// void ReportLedger::deleteDialog(const QModelIndex& index)
// {
//     if (deleteCheckbox->checkState()) {

//         QMessageBox msgBox(QMessageBox::Question, tr("Delete?!"),
//                            tr("Delete this record?"), { }, this);
//         msgBox.addButton(QMessageBox::Yes);
//         msgBox.addButton(QMessageBox::No);
//         msgBox.setDefaultButton(QMessageBox::No);
//         int reply = msgBox.exec();

//         if (reply == QMessageBox::Yes){
//             int row = index.row();
//             int column = index.column();
//             QVariant value = index.sibling(index.row(),0).data(); //will return cell

//             qDebug() << "row " << row << QTime::currentTime();
//             qDebug() << "column " << column << QTime::currentTime();
//             qDebug() << "value " << value.toInt() << QTime::currentTime();

//             QSqlQuery query;
//             query.exec("DELETE FROM " + tableTempName+ " WHERE ctgId='" + value.toString() + "'");
//             tblModel->setSort(0, Qt::AscendingOrder);
//             tblModel->select();
//         }
//     }
// }

// void ReportLedger::checkboxStatus()
// {
//     qDebug() << "checkboxStatus " << deleteCheckbox->checkState();

//     if (deleteCheckbox->checkState()) {
//         tblView->setStyleSheet("QTableView { border: none;"
//                                "background-color: pink;"
//                                "selection-color: black;"
//                                "selection-background-color: yellow}");
//     }else{
//         tblView->setStyleSheet("QTableView { border: none;"
//                                "background-color: white;"
//                                "selection-color: black;"
//                                "selection-background-color: cyan}");
//     }
// }

void ReportLedger::clearFilter()
{
    searchText->setText("");
    tblModel->setFilter("");
    tblModel->setSort(0, Qt::AscendingOrder);
    tblModel->select();
    tblView->resizeColumnsToContents();
}

void ReportLedger::filterRegularExpressionChanged()
{
    qDebug() << "filterRegularExpressionChanged " << searchText->text();

    QVariant value = searchText->text();

    tblModel->setFilter(QString("ledSKU = '" + value.toString() +"'"));

    tblModel->setSort(0, Qt::AscendingOrder);
    tblModel->select();
}

void ReportLedger::filterRegularExpressionChangedItem()
{
    qDebug() << "filterRegularExpressionChanged " << searchText->text();

    QVariant value = searchTextItem->text();

    tblModelItem->setFilter(QString("itemSKU like '%%1%' OR itemCategory like '%%1%' "
                                    "OR itemName like '%%1%'").arg(value.toString()));

    tblModelItem->setSort(0, Qt::AscendingOrder);
    tblModelItem->select();
}

void ReportLedger::clearFilterItem()
{
    searchTextItem->setText("");
    tblModelItem->setFilter("");
    tblModelItem->setSort(0, Qt::AscendingOrder);
    tblModelItem->select();
    tblViewItem->resizeColumnsToContents();
}

void ReportLedger::itemToLedger(const QModelIndex& index)
{
    QVariant value = index.sibling(index.row(),0).data(); //will return cell
    tblModel->setFilter(QString("ledSKU = '" + value.toString() +"'"));
    tblModel->setSort(0, Qt::AscendingOrder);
    tblModel->select();
}

void ReportLedger::itemDouble(const QModelIndex& index)
{
    qDebug() << "ccc " << index;
}
