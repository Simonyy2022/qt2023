#include "mainwindow.h"

#include <QAction>
#include <QFileDialog>
#include <QMenuBar>

#include <QtWidgets>

#include "transactions/transsales.h"
#include "transactions/transtransferin.h"
#include "transactions/todaysales.h"

#include "products/productscategory.h"
#include "products/productsitem.h"

#include "report/reportledger.h"

#include <QListView>
#include <QLabel>
#include <QVBoxLayout>
#include <QPalette>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow{parent}
{
    // -- create Transactions menu

    QMenu *dailyMenu = menuBar()->addMenu(tr("&Transactions"));

    QAction *salesAct = new QAction(tr("&Sales..."), this);
    dailyMenu->addAction(salesAct);
    connect(salesAct, &QAction::triggered, this, &MainWindow::salesAct);

    dailyMenu->addSeparator();

    QAction *transferinAct = new QAction(tr("Transfer &In..."), this);
    dailyMenu->addAction(transferinAct);
    connect(transferinAct, &QAction::triggered, this, &MainWindow::transferinAct);

    QAction *transferoutAct = new QAction(tr("Transfer &Out..."), this);
    dailyMenu->addAction(transferoutAct);

    dailyMenu->addSeparator();

    QAction *todaysalesAct = new QAction(tr("&Today's Sales..."), this);
    dailyMenu->addAction(todaysalesAct);
    connect(todaysalesAct, &QAction::triggered, this, &MainWindow::todaysalesAct);

    // -- create Products menu

    QMenu *depMenu = menuBar()->addMenu(tr("&Products"));

    QAction *categoryAct = new QAction(tr("&Category..."), this);
    depMenu->addAction(categoryAct);
    connect(categoryAct, &QAction::triggered, this, &MainWindow::categoryAct);

    QAction *itemAct = new QAction(tr("&Item..."), this);
    depMenu->addAction(itemAct);
    connect(itemAct, &QAction::triggered, this, &MainWindow::itemAct);

    // -- create Report menu

    QMenu *reportMenu = menuBar()->addMenu(tr("&Report"));

    QAction *ledgerAct = new QAction(tr("&Ledger Report..."), this);
    reportMenu->addAction(ledgerAct);
    connect(ledgerAct, &QAction::triggered, this, &MainWindow::ledgerAct);

    // -- create Maintainance menu

    QMenu *maintenanceMenu = menuBar()->addMenu(tr("&Maintainance"));

    QAction *customerAct = new QAction(tr("&Customer..."), this);
    maintenanceMenu->addAction(customerAct);

    QAction *employeeAct = new QAction(tr("&Employee..."), this);
    maintenanceMenu->addAction(employeeAct);

    maintenanceMenu->addSeparator();

    QAction *settingAct = new QAction(tr("&Setting..."), this);
    maintenanceMenu->addAction(settingAct);

    // -- create Others menu

    QMenu *othersMenu = menuBar()->addMenu(tr("&Others"));

    QAction *aboutAct = new QAction(tr("&About Us..."), this);
    othersMenu->addAction(aboutAct);

    // -- set window title

    setWindowTitle(tr("POS System"));

    // -- set background

    QPixmap bkgnd(":/images/fresh-from-the-fryer-d-1x_1.jpg");
    bkgnd = bkgnd.scaled(this->size(), Qt::KeepAspectRatio);
    QPalette palette;
    palette.setBrush(QPalette::Window, bkgnd);
    this->setPalette(palette);
}

void MainWindow::categoryAct()
{
    qDebug() << "MainWindow::menuAct ++";

        ProductsCategory editor("tblCategory");
        editor.resize(600,300);
        editor.show();
        editor.exec();

    qDebug() << "MainWindow::menuAct --";
}

void MainWindow::itemAct()
{
    qDebug() << "MainWindow::itemAct ++";

    ProductsItem editor;
    editor.resize(600,300);
    editor.show();
    editor.exec();

    qDebug() << "MainWindow::itemAct --";
}

void MainWindow::ledgerAct()
{
    qDebug() << "MainWindow::ledgerAct ++";

    ReportLedger editor("tblLedger");
    editor.resize(800,500);
    editor.show();
    editor.exec();

    qDebug() << "MainWindow::ledgerAct --";
}

void MainWindow::salesAct()
{
    qDebug() << "MainWindow::salesAct ++";

    TransSales editor;
    editor.resize(700,300);
    editor.show();
    editor.exec();

    qDebug() << "MainWindow::salesAct --";
}

void MainWindow::transferinAct()
{
    qDebug() << "MainWindow::transferinAct ++";

    TransTransferIn editor;
    editor.resize(700,500);
    editor.show();
    editor.exec();

    qDebug() << "MainWindow::transferinAct --";
}

void MainWindow::todaysalesAct()
{
    qDebug() << "MainWindow::salesReportAct ++";

    TodaySales editor;
    editor.resize(600,500);
    editor.show();
    editor.exec();

    qDebug() << "MainWindow::salesReportAct --";
}

