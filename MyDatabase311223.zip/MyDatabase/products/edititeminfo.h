#ifndef EDITITEMINFO_H
#define EDITITEMINFO_H

#include <QDialog>

QT_BEGIN_NAMESPACE
class QSqlTableModel;
class QComboBox;
class QLabel;
class QPushButton;
class QLineEdit;
QT_END_NAMESPACE

class EditItemInfo : public QDialog
{

    Q_OBJECT

    private:

        QComboBox *itCategoryText;

        QLabel *rowLabel;
        QLabel *skuLabel;
        QLineEdit *categoryLineEdit;
        QLineEdit *nameLineEdit;
        QLineEdit *priceLineEdit;
        QLineEdit *qtyLineEdit;

        QSqlTableModel *tblModel;

        int originalQty;

    public:

        EditItemInfo(const QString &argRow, const QString &argSKU,
                        const QString &argCategory, const QString &argName,
                        const QString &argPrice, const QString &argQty,
                        QWidget *parent = nullptr);

        QString edRow() const;
        QString edSKU() const;
        QString edCategory() const;
        QString edName() const;
        QString edPrice() const;
        QString edQty() const;
        QString edOriQty() const;

};

#endif // EDITITEMINFO_H
