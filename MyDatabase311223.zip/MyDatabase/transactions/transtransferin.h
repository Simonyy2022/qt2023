#ifndef TRANSTRANSFERIN_H
#define TRANSTRANSFERIN_H

#include <QDialog>
#include <QObject>

class TransTransferIn : public QDialog
{
    Q_OBJECT

public:

    explicit TransTransferIn(QWidget *parent = nullptr);
};

#endif // TRANSTRANSFERIN_H
