// Copyright (C) 2016 The Qt Company Ltd.
// SPDX-License-Identifier: LicenseRef-Qt-Commercial OR BSD-3-Clause

#include <QtWidgets>
#include <QtSql>

#include "productscategory.h"
#include "addcategory.h"

#include <QModelIndex>

ProductsCategory::ProductsCategory(const QString &tableName, QWidget *parent)
    : QDialog(parent)
{
    // -- define temp table name

    tableTempName = tableName;

    // -- set table

    tblModel = new QSqlTableModel(this);
    tblModel->setTable(tableName);
    tblModel->setEditStrategy(QSqlTableModel::OnFieldChange);
    tblModel->setSort(0, Qt::AscendingOrder);
    tblModel->select();

    // -- set header

    tblModel->setHeaderData(0, Qt::Horizontal, tr("ID"));
    tblModel->setHeaderData(1, Qt::Horizontal, tr("Category"));

    // -- put data into tableview

    tblView = new QTableView(this);
    tblView->setModel(tblModel);
    tblView->resizeColumnsToContents();
    tblView->setStyleSheet("QTableView { border: none;"
                        "background-color: white;"
                        "selection-color: black;"
                        "selection-background-color: cyan}");

    // -- set button

    searchLabel = new QLabel(tr("Search Text : "));
    searchText = new QLineEdit();
    clearButton = new QPushButton(tr("Clear"));

    sortZeroButton = new QPushButton(tr("Sort ID"));
    sortZeroButton->setDefault(true);
    sortOneButton = new QPushButton(tr("Sort Category"));
    addDataButton = new QPushButton(tr("Add"));
    deleteCheckbox = new QCheckBox(tr("Delete"));
    quitButton = new QPushButton(tr("Quit"));

    // -- put button into button box

    buttonBox = new QDialogButtonBox(Qt::Vertical);

    buttonBox->addButton(sortZeroButton, QDialogButtonBox::ActionRole);
    buttonBox->addButton(sortOneButton, QDialogButtonBox::ActionRole);
    buttonBox->addButton(addDataButton, QDialogButtonBox::ActionRole);
    buttonBox->addButton(deleteCheckbox, QDialogButtonBox::ActionRole);
    buttonBox->addButton(quitButton, QDialogButtonBox::RejectRole);

    // -- connect button signal and slot

    connect(searchText, &QLineEdit::textChanged,
            this, &ProductsCategory::filterRegularExpressionChanged);

    connect(clearButton, &QPushButton::clicked, this, &ProductsCategory::clearFilter);

    connect(sortZeroButton, &QPushButton::clicked, this, &ProductsCategory::sortZeroView);
    connect(sortOneButton, &QPushButton::clicked, this, &ProductsCategory::sortOneView);
    connect(addDataButton, &QPushButton::clicked, this, &ProductsCategory::showAddEntryDialog);
    connect(deleteCheckbox, &QCheckBox::clicked, this, &ProductsCategory::checkboxStatus);
    connect(quitButton, &QPushButton::clicked, this, &ProductsCategory::close);

    connect(tblView, SIGNAL(clicked(QModelIndex)), this, SLOT(deleteDialog(QModelIndex)));

    // -- add view into QHBoxLayout

    QHBoxLayout *searchLayout = new QHBoxLayout;
    searchLayout->addWidget(searchLabel);
    searchLayout->addWidget(searchText);
    searchLayout->addWidget(clearButton);

    QVBoxLayout *firstLayout = new QVBoxLayout();
    firstLayout->addLayout(searchLayout);
    firstLayout->addWidget(tblView);

    QHBoxLayout *mainLayout = new QHBoxLayout;
    mainLayout->addLayout(firstLayout);
    mainLayout->addWidget(buttonBox);
    setLayout(mainLayout);

    // -- set window title
    setWindowTitle(tr("Category"));

    qDebug() << "ProductsCategory::ProductsCategory --" << tableName;
}

void ProductsCategory::showAddEntryDialog()
{
    AddCategory aDialog;

    if (aDialog.exec())
        addEntry(aDialog.ctgrId(), aDialog.ctgrName());
}

void ProductsCategory::addEntry(const QString &id, const QString &name)
{
    QSqlQuery query;

    qDebug() << "tempname 2" << tableTempName;

    query.exec("insert into " + tableTempName + " values('"+id+"', '"+name+"')");
    tblModel->select();
    tblView->resizeColumnsToContents();
}

void ProductsCategory::sortZeroView()
{
    tblModel->setSort(0, Qt::AscendingOrder);
    tblModel->select();
}

void ProductsCategory::sortOneView()
{
    tblModel->setSort(1, Qt::AscendingOrder);
    tblModel->select();
}

void ProductsCategory::deleteDialog(const QModelIndex& index)
{
    if (deleteCheckbox->checkState()) {

        QMessageBox msgBox(QMessageBox::Question, tr("Delete?!"),
                           tr("Delete this record?"), { }, this);
        msgBox.addButton(QMessageBox::Yes);
        msgBox.addButton(QMessageBox::No);
        msgBox.setDefaultButton(QMessageBox::No);
        int reply = msgBox.exec();

        if (reply == QMessageBox::Yes){
            int row = index.row();
            int column = index.column();
            QVariant value = index.sibling(index.row(),0).data(); //will return cell

            qDebug() << "row " << row << QTime::currentTime();
            qDebug() << "column " << column << QTime::currentTime();
            qDebug() << "value " << value.toInt() << QTime::currentTime();

            QSqlQuery query;
            query.exec("DELETE FROM " + tableTempName+ " WHERE ctgId='" + value.toString() + "'");
            tblModel->setSort(0, Qt::AscendingOrder);
            tblModel->select();
        }
    }
}

void ProductsCategory::checkboxStatus()
{
    qDebug() << "checkboxStatus " << deleteCheckbox->checkState();

    if (deleteCheckbox->checkState()) {
        tblView->setStyleSheet("QTableView { border: none;"
                                       "background-color: pink;"
                                       "selection-color: black;"
                                       "selection-background-color: yellow}");
    }else{
        tblView->setStyleSheet("QTableView { border: none;"
                            "background-color: white;"
                            "selection-color: black;"
                            "selection-background-color: cyan}");
    }
}

void ProductsCategory::clearFilter()
{
    searchText->setText("");
    tblModel->setFilter("");
    tblModel->setSort(0, Qt::AscendingOrder);
    tblModel->select();
    tblView->resizeColumnsToContents();
}

void ProductsCategory::filterRegularExpressionChanged()
{
    qDebug() << "filterRegularExpressionChanged " << searchText->text();

    QVariant value = searchText->text();

    tblModel->setFilter(QString("ctgId like '%%1%' OR ctgName like '%%1%'").arg(value.toString()));

    tblModel->setSort(0, Qt::AscendingOrder);
    tblModel->select();
}

