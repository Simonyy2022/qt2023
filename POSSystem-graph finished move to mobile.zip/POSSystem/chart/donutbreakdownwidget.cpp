// Copyright (C) 2023 The Qt Company Ltd.
// SPDX-License-Identifier: LicenseRef-Qt-Commercial OR GPL-3.0-only

#include "donutbreakdownchart.h"
#include "donutbreakdownwidget.h"

#include <QChart>
#include <QPieSeries>

#include <QtSql>

DonutBreakdownWidget::DonutBreakdownWidget(QWidget *parent)
    : ContentWidget(parent)
{

    // -- copy to tblTemporary

    QSqlQuery query;
    QSqlQuery query2; // not mess up with tblsales and tbltemporary

    query2.exec("DELETE FROM tblTemporary");

    tblModel = new QSqlTableModel(this);
    tblModel->setTable("tblSalesMain");

    QVariant value = "" + QDate::currentDate().toString("yyyy-MM-dd") + "";
    tblModel->setFilter(QString("slmDate = '" + value.toString() +"'"));

    tblModel->setSort(0, Qt::AscendingOrder);
    tblModel->select();

    QVariant data[5];

    for(int row=0; row < tblModel->rowCount(); ++row)
    {
        for(int i = 0; i < 5; i++)
        {
            data[i] = tblModel->data(tblModel->index(row,i));
        }

        query.exec("SELECT * FROM tblSales WHERE slsNo == '" + data[0].toString() +"'");
        while (query.next())
        {
            query2.exec("insert into tblTemporary values("
                "'" + query.value(0).toString() + "', "
                "'" + query.value(1).toString() + "', "
                "'" + query.value(2).toString() + "', "
                "'" + query.value(3).toString() + "', "
                "'" + query.value(4).toString() + "', "
                "'" + query.value(5).toString() + "', "
                "'" + query.value(6).toString() + "')");
        }
    }

    query.exec("SELECT column02, SUM(column05), SUM(column06) FROM tblTemporary GROUP BY column02 ORDER BY SUM(column06) DESC");

    auto series1 = new QPieSeries;
    series1->setName("Category");

    while (query.next()) {
        series1->append("" + query.value(0).toString() +"", query.value(2).toInt());
    }

    auto donutBreakdown = new DonutBreakdownChart;
    donutBreakdown->setAnimationOptions(QChart::AllAnimations);
    donutBreakdown->setTitle("Today's Sales % by Category (Amount)");
    donutBreakdown->legend()->setAlignment(Qt::AlignRight);
    donutBreakdown->addBreakdownSeries(series1, Qt::darkGreen);

    createDefaultChartView(donutBreakdown);
}
