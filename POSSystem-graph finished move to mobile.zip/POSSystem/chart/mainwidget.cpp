// Copyright (C) 2023 The Qt Company Ltd.
// SPDX-License-Identifier: LicenseRef-Qt-Commercial OR GPL-3.0-only


#include "barwidget.h"
#include "donutbreakdownwidget.h"

#include "mainwidget.h"

#include <QApplication>
#include <QHBoxLayout>
#include <QListView>
#include <QModelIndex>
#include <QStringListModel>
#include <QVBoxLayout>

#include <algorithm>

#include <QtWidgets>

MainWidget::MainWidget(QWidget *parent)
    : QWidget(parent)
    , m_listModel(new QStringListModel(this))
    , m_contentArea(new QWidget(this))
{
    m_exampleMap.insert(tr("Bar Chart"), BarChart);
    m_exampleMap.insert(tr("Donut Breakdown"), DonutBreakdown);

    QStringList examples = m_exampleMap.keys();
    std::sort(examples.begin(), examples.end());
    m_listModel->setStringList(examples);

    m_contentArea->installEventFilter(this);

    barButton = new QPushButton(tr("Bar"));
    pieButton = new QPushButton(tr("Pie"));
    quitButton = new QPushButton(tr("Quit"));

    setMinimumSize(800, 400);
    resize(1200, 600);

    connect(barButton, &QPushButton::clicked, this, &MainWidget::barChart);
    connect(pieButton, &QPushButton::clicked, this, &MainWidget::pieChart);
    connect(quitButton, &QPushButton::clicked, this, &MainWidget::close);

    setActiveExample(m_exampleMap[examples[0]]);

    setMouseTracking(true);

    qApp->setApplicationDisplayName(tr("POS System"));
}

void MainWidget::resizeEvent(QResizeEvent *)
{
    bool isHorizontal = width() >= height();
    if (!layout() || isHorizontal != m_isHorizontal)
        relayout(isHorizontal);
}

bool MainWidget::eventFilter(QObject *object, QEvent *event)
{
    if (event->type() == QEvent::Resize && object == m_contentArea && m_activeWidget)
        m_activeWidget->resize(m_contentArea->size());
    return QObject::eventFilter(object, event);
}

void MainWidget::setActiveExample(Example example)
{
    // We only keep one example alive at the time to save resources.
    // This also allows resetting the example by switching to another example and back.
    if (m_activeWidget) {
        m_activeWidget->setVisible(false);
        m_activeWidget->deleteLater();
    }

    switch (example) {
        case BarChart:
            m_activeWidget = new BarWidget(m_contentArea);
            break;
        case DonutBreakdown:
            m_activeWidget = new DonutBreakdownWidget(m_contentArea);
            break;
    }

    m_activeWidget->load();
    m_activeWidget->resize(m_contentArea->size());
    m_activeWidget->setVisible(true);
}

void MainWidget::relayout(bool horizontal)
{
    m_isHorizontal = horizontal;

    delete layout();

    QVBoxLayout *layout = new QVBoxLayout(this);
    layout->addWidget(m_contentArea); // right content area
    layout->addWidget(barButton);
    layout->addWidget(pieButton);
    layout->addWidget(quitButton);

    setLayout(layout);
}

void MainWidget::barChart()
{
    if (m_activeWidget) {
        m_activeWidget->setVisible(false);
        m_activeWidget->deleteLater();
    }

    m_activeWidget = new BarWidget(m_contentArea);
    m_activeWidget->load();
    m_activeWidget->resize(m_contentArea->size());
    m_activeWidget->setVisible(true);
}

void MainWidget::pieChart()
{
    if (m_activeWidget) {
        m_activeWidget->setVisible(false);
        m_activeWidget->deleteLater();
    }

    m_activeWidget = new DonutBreakdownWidget(m_contentArea);
    m_activeWidget->load();
    m_activeWidget->resize(m_contentArea->size());
    m_activeWidget->setVisible(true);
}
