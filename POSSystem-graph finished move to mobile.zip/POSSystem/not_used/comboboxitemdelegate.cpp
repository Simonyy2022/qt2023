#include "comboboxitemdelegate.h"
#include <QComboBox>

#include <QSqlTableModel>

ComboBoxItemDelegate::ComboBoxItemDelegate(QObject *parent)
    : QStyledItemDelegate(parent)
{
}

ComboBoxItemDelegate::~ComboBoxItemDelegate()
{
}

QWidget *ComboBoxItemDelegate::createEditor(QWidget *parent,
    const QStyleOptionViewItem &option, const QModelIndex &index) const
{
    qDebug() << option << index;

    // -- set category

    QSqlTableModel* tblModel = new QSqlTableModel(parent);
    tblModel->setTable("tblCategory");
    tblModel->setSort(1, Qt::AscendingOrder);
    tblModel->select();

    QComboBox *cb = new QComboBox(parent);

    for(int row=0; row < tblModel->rowCount(); ++row)
    {
        QVariant data = tblModel->data(tblModel->index(row,1));
        cb->addItem("" + data.toString() + "");
    }

    return cb;
}

void ComboBoxItemDelegate::setEditorData(QWidget *editor, const QModelIndex &index) const
{
    QComboBox *cb = qobject_cast<QComboBox *>(editor);
    Q_ASSERT(cb);
    // get the index of the text in the combobox that matches the current value of the item
    const QString currentText = index.data(Qt::EditRole).toString();
    const int cbIndex = cb->findText(currentText);
    // if it is valid, adjust the combobox
    if (cbIndex >= 0)
        cb->setCurrentIndex(cbIndex);
}

void ComboBoxItemDelegate::setModelData(QWidget *editor,
    QAbstractItemModel *model, const QModelIndex &index) const
{
    QComboBox *cb = qobject_cast<QComboBox *>(editor);
    Q_ASSERT(cb);
    model->setData(index, cb->currentText(), Qt::EditRole);
}
