#include "transsales.h"
#include "editqty.h"

#include <QtWidgets>
#include <QSqlTableModel>

#include <QtSql>
#include <QDate>

TransSales::TransSales(QWidget *parent) : QDialog(parent)
{
    // -- intialise table item

    tblModel = new QSqlTableModel(this);
    tblModel->setTable("tblItem");

    // -- qty and amount

    space1= new QSpacerItem(0,5, QSizePolicy::Expanding, QSizePolicy::Expanding);

    QFont fQty( "Monospace", 15, QFont::Bold);
    QFont fAmount( "Monospace", 20, QFont::Bold);

    qtyLabel = new QLabel(tr("Qty : 0"));
    qtyLabel->setFont(fQty);
    qtyLabel->setStyleSheet("QLabel { color : blue; }");

    amountLabel = new QLabel(tr(" Amount : 0.00"));
    amountLabel->setFont(fAmount);
    amountLabel->setStyleSheet("QLabel { color : brown; }");

    // -- sku search

    skuLabel = new QLabel(tr("SKU : "));
    searchText = new QLineEdit();
    enterButton = new QPushButton(tr("Enter"));
    completedButton = new QPushButton(tr("Completed"));

    // -- QTableWidget

    twSales = new QTableWidget(this);

    QStringList headers;
    twSales->setColumnCount(6);
    headers << "SKU" << "Category" << "Name" << "Price" << "Qty" << "Amount";
    twSales->setHorizontalHeaderLabels(headers);

    twSales->setColumnCount(6);
    twSales->setRowCount(1);

    twSales->setEditTriggers(QAbstractItemView::NoEditTriggers);

    // -- connect

    connect(enterButton, &QPushButton::clicked, this, &TransSales::skuEnter);
    connect(completedButton, &QPushButton::clicked, this, &TransSales::completedEnter);

    connect(twSales, SIGNAL(clicked(QModelIndex)), this, SLOT(deleteEdit(QModelIndex)));

    // -- layout

    QHBoxLayout *searchLayout = new QHBoxLayout;
    searchLayout->addWidget(skuLabel);
    searchLayout->addWidget(searchText);
    searchLayout->addWidget(enterButton);
    searchLayout->addWidget(completedButton);

    QHBoxLayout *calculateLayout = new QHBoxLayout;
    calculateLayout->addItem(space1);
    calculateLayout->addWidget(qtyLabel);
    calculateLayout->addWidget(amountLabel);

    QVBoxLayout *mainLayout = new QVBoxLayout;
    mainLayout->addLayout(calculateLayout);
    mainLayout->addLayout(searchLayout);
    mainLayout->addWidget(twSales);
    setLayout(mainLayout);

    // -- set window title

    setWindowTitle(tr("Sales Screen"));

}

void TransSales::skuEnter()
{

    // -- get sku

    QVariant value = searchText->text();

    // -- filter sku

    tblModel->setFilter(QString("itemSKU = '" + value.toString() +"'"));
    tblModel->select();

    // -- put data into QTableWidget -- simpler method

    searchText->setText("");

    if(tblModel->rowCount() == 1)
    {
        int rc = twSales->rowCount() - 1;
        QVariant data[4];
        for(int i = 0; i < 4; i++)
        {
            data[i] = tblModel->data(tblModel->index(0,i));
            if(i==3)
            {
                QVariant temp = QString::number(data[i].toFloat(), 'f', 2); // 071223 set decimal places
                QTableWidgetItem * item = new QTableWidgetItem("" + temp.toString() + "");
                twSales->setItem(rc, i, item);
                twSales->item(rc,3)->setTextAlignment(Qt::AlignCenter); // price 071223
            }else{
                QTableWidgetItem * item = new QTableWidgetItem("" + data[i].toString() + "");
                twSales->setItem(rc, i, item);
            }
        }

        // -- set qty to 1

        QTableWidgetItem* item = new QTableWidgetItem("" + QString::number(1) + "");
        twSales->setItem(rc, 4, item);
        twSales->item(rc,4)->setTextAlignment(Qt::AlignCenter); // 071223

        // -- set qty * price = amount

        QVariant temp = QString::number(data[3].toFloat(), 'f', 2); // 071223 set decimal places
        QTableWidgetItem * item2 = new QTableWidgetItem("" + temp.toString() + "");
        twSales->setItem(rc, 5, item2);
        twSales->item(rc,5)->setTextAlignment(Qt::AlignCenter); // 071223

        // -- add new row

        twSales->insertRow(twSales->rowCount());
    }

    calculateSales();

} // end of void TransSales::skuEnter()

void TransSales::deleteEdit(const QModelIndex& index)
{
    qDebug() << "deleteEdit ++";

    QVariant row = index.row();
    QVariant sku = index.sibling(index.row(),0).data();
    QVariant qty = index.sibling(index.row(),4).data();

    if(sku.toString()=="") return; // no sku no popup message box

    QMessageBox msgBox(QMessageBox::Question, tr("Edit Qty"),
                       tr("Edit this record? %1").arg(sku.toString()), { }, this);
    msgBox.addButton(QMessageBox::Yes);
    msgBox.addButton(QMessageBox::No);
    msgBox.setDefaultButton(QMessageBox::No);

    int reply = msgBox.exec();

    if (reply == QMessageBox::Yes)
    {
        EditQty showDialog(""+ row.toString() + "", ""+ sku.toString() + "", ""+ qty.toString() + "");

        if (showDialog.exec())
            updateTblWidgwt(showDialog.edRow(), showDialog.edSKU(), showDialog.edQty());
    }

    qDebug() << "deleteEdit --";
}

void TransSales::updateTblWidgwt(const QString &row, const QString &sku, const QString &qty)
{
    qDebug() << "TransSales::addEntry ++";

    QString SKU = twSales->item(row.toInt(), 0)->text();

    if(SKU == sku)
    {
        // -- set qty

        QTableWidgetItem* item = new QTableWidgetItem("" + qty + "");
        twSales->setItem(row.toInt(), 4, item);
        twSales->item(row.toInt(),4)->setTextAlignment(Qt::AlignCenter); // 071223

        // -- set amount

        QString price = twSales->item(row.toInt(), 3)->text();
        double amount = qty.toDouble() * price.toDouble();
        QVariant temp = QString::number(amount, 'f', 2); // 071223 set decimal places
        QTableWidgetItem * item2 = new QTableWidgetItem("" + temp.toString() + "");
        twSales->setItem(row.toInt(), 5, item2);
        twSales->item(row.toInt(),5)->setTextAlignment(Qt::AlignCenter); // 071223
    }

    calculateSales();

}

void TransSales::calculateSales()
{

    // -- calculate qty and amount

    int qtyCalculate=0;
    double amountCalculate=0.00;
    for(int i = 0; i < twSales->rowCount()-1; i++)
    {
        qtyCalculate = qtyCalculate + twSales->item(i,4)->text().toInt();
        amountCalculate = amountCalculate + twSales->item(i,5)->text().toDouble();
    }

    qtyLabel->setText("Qty : " + QString::number(qtyCalculate));
    amountLabel->setText(" Amount : " + QString::number(amountCalculate, 'f', 2));

}

void TransSales::completedEnter()
{

    if(twSales->rowCount() == 1) return; // do nothing if no sku enter

    // -- get sales number

    QSqlQuery query;
    query.exec("SELECT * FROM tblNumbers WHERE numType = 'Sales'");

    int num = 0;
    while (query.next()) {
        QString numType = query.value(0).toString();
        QString numNumber = query.value(1).toString();
        if(numType == "Sales"){
            num = 1 + numNumber.toInt();
        }
    }

    // -- update sales table one by one sku

    int qtyCalculate=0;
    double amountCalculate=0.00;

    for(int i = 0; i < twSales->rowCount()-1; i++)
    {
        qtyCalculate = qtyCalculate + twSales->item(i,4)->text().toInt();
        amountCalculate = amountCalculate + twSales->item(i,5)->text().toDouble();

        QSqlQuery query;

        // ** update sales table

        query.exec("insert into tblSales values('" + QString::number(num) + "', "
                    "'" + twSales->item(i,0)->text() + "', "
                    "'" + twSales->item(i,1)->text() + "', "
                    "'" + twSales->item(i,2)->text() + "', "
                    "'" + twSales->item(i,3)->text() + "', "
                    "'" + twSales->item(i,4)->text() + "', "
                    "'" + twSales->item(i,5)->text() + "')");

        // ** get item qty and deduct with sales qty

        query.exec("SELECT * FROM tblItem WHERE itemSKU = '"+ twSales->item(i,0)->text() +"'");
        int itemQty=0;
        while (query.next()) {
            itemQty = query.value(4).toInt() - twSales->item(i,4)->text().toInt();
            query.exec("UPDATE tblItem SET itemQty = '" + QString::number(itemQty) + "' "
                        "WHERE itemSKU = '"+ twSales->item(i,0)->text() +"'");
        }

        // ** update ledger

        query.exec("insert into tblLedger values("
            "'" + QDate::currentDate().toString("yyyy-MM-dd") + "', "
            "'" + QTime::currentTime().toString("hh:mm:ss") + "', "
            "'Sales', "
            "'" + QString::number(num) + "',"
            "'"+ twSales->item(i,0)->text() +"', "
            "'"+ twSales->item(i,1)->text() +"', "
            "'"+ twSales->item(i,2)->text() +"', "
            "'"+ twSales->item(i,3)->text() +"', "
            "'"+ twSales->item(i,4)->text() +"', "
            "'"+ QString::number(itemQty) +"')");
    }

    // -- update salemain table

    query.exec("insert into tblSalesMain values('" + QString::number(num) + "', "
                "'" + QDate::currentDate().toString("yyyy-MM-dd") + "', "
                "'" + QTime::currentTime().toString("hh:mm:ss") + "', "
                "'" + QString::number(qtyCalculate) + "', "
                "'" + QString::number(amountCalculate, 'f', 2) + "')");

    // -- update numbers table

    query.exec("UPDATE tblNumbers SET numNumber = '" + QString::number(num) + "' "
                "WHERE numType = 'Sales'");

    // -- clear tblwidget

    twSales->clear();
    twSales->setRowCount(1);

    // -- reinitialize qty and amount

    qtyLabel->setText("Qty : 0");
    amountLabel->setText(" Amount : 0.00");

}
